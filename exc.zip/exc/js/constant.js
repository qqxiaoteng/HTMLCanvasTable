const isDebug = true

const EventStatus = {
  IDLE: 0,
  
  CODE_ON: 11,
 
}
var eventStatus = EventStatus.IDLE;

var defaultStrokeColor = "#ff00ee";  // 默认线条色
var defaultFillColor = "#ffffff"
